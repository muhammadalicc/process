# Kunlik Telegram Bot

Har kuni foydalanuvchiga odatlar eslatmasini yuboradigan oddiy Telegram bot.